"""cd "D:\Pycharm File\project_root\app"
streamlit run streamlit_app.py"""


# === AI Öğrenme Chatbotu: BERT + Gemini ===

from transformers import BertTokenizer, BertForSequenceClassification
import torch
import streamlit as st
import pandas as pd
import json
import os
from dotenv import load_dotenv
import google.generativeai as genai

# Ortam değişkenleri
load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

# Model ve etiket eşlemelerini yükle
model_path = "../outputs/models/results/checkpoint-255"

model = BertForSequenceClassification.from_pretrained(model_path)
tokenizer = BertTokenizer.from_pretrained(model_path)
with open("../outputs/models/label_map.json", "r", encoding="utf-8") as f:
    id2label = json.load(f)
    label2id = {v: int(k) for k, v in id2label.items()}

# Gemini modeli
gemini_model = genai.GenerativeModel("models/gemini-1.5-flash")

# Streamlit UI
st.set_page_config(page_title="🤖 AstraNova", layout="wide")

# === Intent örnekleri ve kısa cevaplar ===
intent_examples = {
    "ai_nedir": ["AI tam olarak ne demek?", "AI ve insan zekası arasındaki fark nedir?", "AI tam olarak ne demek?"],
    "makine_ogrenmesi": ["Supervised ve unsupervised öğrenme ne demek?", "Makine öğrenmesinin temel kavramları neler?", "ML ile AI farkı nedir?"],
    "derin_ogrenme": ["Derin öğrenme ile makine öğrenmesi farkı ne?", "Hangi problemler için DL uygundur?", "CNN ve RNN farkı nedir?"],
    "neuron_aglari": ["Sinir ağı eğitiminde neye dikkat edilir?", "Katman sayısı modelin başarısını etkiler mi?", "Sinir ağı eğitiminde neye dikkat edilir?"],
    "veri_on_isleme": ["Veri ön işleme neden önemlidir?", "Veri ön işleme neden önemlidir?", "Veri ön işleme neden önemlidir?"],
    "model_egitimi": ["Overfitting nasıl önlenir?", "Model eğitimi için hangi veriler seçilmeli?", "Epoch sayısı model kalitesini etkiler mi?"],
    "hata_turleri": ["False positive nedir?", "Precision ve recall farkı nedir?", "Hata türleri nasıl analiz edilir?"],
    "metrikler": ["F1-score nasıl hesaplanır?", "Accuracy neden tek başına yeterli değildir?", "Precision ne işe yarar?"],
    "gorsel_uygulamalar": ["Görüntü işleme nerelerde kullanılır?", "Nesne tanıma nasıl çalışır?", "Görüntü sınıflandırma için örnek proje var mı?"],
    "metin_uygulamalari": ["Chatbot nasıl yapılır?", "Metin sınıflandırma örneği verir misin?", "Dil modeli nedir?"],
    "kaynak_onerisi": ["AI öğrenmek için hangi kaynakları önerirsiniz?", "En iyi AI kursları hangileri?", "Yeni başlayanlar için kitap önerisi var mı?"],
    "proje_fikirleri": ["AI ile yapılabilecek basit projeler neler?", "Yeni başlayanlar için proje önerisi?", "Proje fikirleri verir misiniz?"],
    "python_kutuphaneleri": ["Scikit-learn ne işe yarar?", "TensorFlow ve PyTorch farkı nedir?", "Numpy neden önemlidir?"],
    "llm_chatbot": ["LLM chatbot nasıl yapılır?", "LLM modeli eğitmek zor mu?", "Chatbot örneği var mı?"],
    "terim_aciklamalari": ["Overfitting ne demek?", "Dropout nedir?", "Epoch ne demek?"]
}

intent_short_responses = {
    "selamlasma": "👋 Merhaba! Size nasıl yardımcı olabilirim?",
    "vedalasma": "👋 Görüşmek üzere! Başarılar dilerim."
}

# === Stil tanımları ===
st.markdown("""
<style>
body {
    background-color: #f5f7fa;
    color: #222;
}
.big-title {
    font-size:28px !important;
    font-weight:bold;
    color:#2c3e50;
    margin-bottom: 10px;
}
.select-small .stSelectbox > div {
    font-size: 14px;
    padding: 6px 10px;
}
.divider {
    border-left: 2px solid #ccc;
    height: 100%;
    position: absolute;
    left: 50%;
    top: 0;
}
.chat-bubble-user {
    background-color: #e3f2fd;
    color: #0d47a1;
    padding: 10px;
    border-radius: 10px;
    margin-bottom: 5px;
}
.chat-bubble-bot {
    background-color: #e8f5e9;
    color: #1b5e20;
    padding: 10px;
    border-radius: 10px;
    margin-bottom: 20px;
}
</style>
""", unsafe_allow_html=True)

col1, _, col2 = st.columns([1, 0.05, 1])

with col1:
    st.markdown("<div class='big-title'>📚 YapaYurt(Yapay zekânın sınırlı cevaplarının yurdu)</div>", unsafe_allow_html=True)
    selected_intent = st.selectbox("Intent seçin:", list(intent_examples.keys()), key="intent_select")
    example_question = st.selectbox("Soru seçin:", intent_examples.get(selected_intent, []), key="question_select")
    send_btn = st.button("📩 Gönder (Intent)", key="send_intent")

    if send_btn:
        if selected_intent in intent_short_responses:
            bot_reply = intent_short_responses[selected_intent]
        else:
            prompt = f"""Aşağıda verilen yapay zekâ konulu soruyu açık, anlaşılır ve doğru şekilde yanıtla.
Cevabın yalnızca 1 paragraftan oluşmalı. Konunun tanımını yap, neden önemli olduğunu ve hangi alanlarda kullanıldığını belirt. Mümkünse sade ve kısa bir örnekle açıklamayı güçlendir. Açıklama teknik olarak doğru olmalı ama herkesin anlayacağı bir seviyede ve akıcı biçimde yazılmalı. Bilgiler öğretici, güvenilir ve doğrudan soruyla ilgili olmalı.

💡 Tahmin edilen konu: '{selected_intent}'
📜 Soru: {example_question}

"""
            with st.spinner("💬 Gemini yanıtlıyor..."):
                response = gemini_model.generate_content(prompt)
                bot_reply = response.text

        st.markdown("### 🤖 Cevap:")
        st.markdown(f"<div class='chat-bubble-user'><strong>Soru:</strong> {example_question}</div>", unsafe_allow_html=True)
        st.markdown(f"<div class='chat-bubble-bot'><strong>Cevap:</strong> {bot_reply}</div>", unsafe_allow_html=True)

with col2:
    st.markdown("<div class='big-title'>🌐 NutukNetAI→ (Özgür Cevapların Modern Hitabesi)</div>", unsafe_allow_html=True)
    with st.form(key="api_form"):
        user_input = st.text_input("📝 Sorunuzu yazın:")
        ask_btn = st.form_submit_button("📤 Gönder")

    if ask_btn and user_input:
        with st.spinner("💬 Gemini yanıtlıyor..."):
            response = gemini_model.generate_content(user_input)
            bot_reply = response.text

        st.markdown("### 🤖 Cevap:")
        st.markdown(f"<div class='chat-bubble-user'><strong>Soru:</strong> {user_input}</div>", unsafe_allow_html=True)
        st.markdown(f"<div class='chat-bubble-bot'><strong>Cevap:</strong> {bot_reply}</div>", unsafe_allow_html=True)

    if st.button("🧹 Cevap Alanını Temizle", key="clear_api"):
        st.rerun()

# Footer
st.markdown("🔪 Bu chatbot BERT modeliyle intent belirler, cevabı Gemini üretir. 🌟")
